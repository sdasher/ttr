package org.webproject.servlet;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.webproject.servlet.DBUtility;

/**
 * Servlet implementation class HttpServlet
 */
@WebServlet("/HttpServlet")
public class HttpServlet extends javax.servlet.http.HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * @see javax.servlet.http.HttpServlet#javax.servlet.http.HttpServlet()
     */
    public HttpServlet() {
        super();
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    }


    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse
            response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        String tab_id = request.getParameter("tab_id");
        if (tab_id.equals("1")) {
            // query form
            try {
                queryReport(request, response);
                System.out.println(request);
            } catch (JSONException e) {
                System.out.println(e.toString());
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (SQLException e) {
                System.out.println(e.toString());
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
               else if (tab_id.equals("2")) {
                try {
                    queryList(request, response);
                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        else if (tab_id.equals("3")) {
            try {
                queryTopTen(request, response);
            } catch (JSONException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        }


    private void createReport(HttpServletRequest request, HttpServletResponse
            response) throws SQLException, IOException {
        System.out.println("Entering create report");
        DBUtility dbutil = new DBUtility();
        String sql;

        // Add query to database pastqueries
        String pastqueriesstr = request.getParameter("name");
        System.out.println(pastqueriesstr);
        sql = "insert into pastqueries (name) " +
                "values ('" + pastqueriesstr + "')";
        dbutil.modifyDB(sql);
        System.out.println(sql);

        // response that the report submission is successful
        JSONObject data = new JSONObject();
        try {
            data.put("status", "success");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        response.getWriter().write(data.toString());
        System.out.println("Exiting create report");
    }

    private void queryReport(HttpServletRequest request, HttpServletResponse
            response) throws JSONException, SQLException, IOException {
        System.out.println("entering queryReport");
        JSONArray list = new JSONArray();

        String st = request.getParameter("st");
        String yr = request.getParameter("yr");
        String gender = request.getParameter("gender");
        String first_name = request.getParameter("first_name");
        String sql = "select first_name, yr, gender, st, namecount, st_X(geom) as longitude, ST_Y(geom)as latitude from statenames where 1=1";


        queryReportHelper(sql, list, yr, st, gender, first_name);

        response.getWriter().write(list.toString());
//Add query name to pastqueries database
        DBUtility dbutil = new DBUtility();
        System.out.println("Entering create report");
        // Add query to database pastqueries
        String pastqueriesname = request.getParameter("first_name");
        String pastqueriessql = "insert into pastqueries (name) " +
                "values ('"+ pastqueriesname + "')";
        dbutil.modifyDB(pastqueriessql);
        System.out.println(pastqueriessql);

    }


    private void queryReportHelper(String sql, JSONArray list, String yr, String st, String gender, String
            first_name) throws SQLException {
        System.out.println("entering queryReportHelper");
        System.out.println(first_name);
        DBUtility dbutil = new DBUtility();

        if (yr != null) {
            sql += " and yr = '" + yr + "'";
        }
        if (st != null) {
            sql += " and st = '" + st + "'";
        }
        if (gender != null) {
            sql += " and gender = '" + gender + "'";
        }
        if (first_name != null) {
            sql += " and first_name = '" + first_name + "';";
        }
        System.out.println(sql);

        ResultSet res = dbutil.queryDB(sql);

        while (res.next()) {
            // add to response
            HashMap<String, String> m = new HashMap<String, String>();
            m.put("first_name", res.getString("first_name"));
            m.put("yr", res.getString("yr"));
            m.put("gender", res.getString("gender"));
            m.put("st", res.getString("st"));
            m.put("namecount", res.getString("namecount"));
            m.put("latitude", res.getString("latitude"));
            m.put("longitude", res.getString("longitude"));
            list.put(m);
        }
        System.out.println(list);
    }


    private void queryList(HttpServletRequest request, HttpServletResponse
            response) throws JSONException, SQLException, IOException {
        JSONArray list = new JSONArray();
        System.out.println("entering queryList");
        DBUtility dbutil = new DBUtility();
        String sql= "select name, count(name) from pastqueries group by name order by count DESC";


        ResultSet res = dbutil.queryDB(sql);

        while (res.next()) {
            // add to response
            HashMap<String, String> m = new HashMap<String, String>();
            m.put("FName", res.getString("name"));
            m.put("Count", res.getString("count"));
            list.put(m);
        }
        System.out.println(list);
        System.out.println("Exiting queryList");
        response.getWriter().write(list.toString());
    }
    private void queryTopTen(HttpServletRequest request, HttpServletResponse
            response) throws JSONException, SQLException, IOException {
        System.out.println("entering queryTopTen");
        JSONArray list = new JSONArray();

        String st = request.getParameter("st");
        String yr = request.getParameter("yr");
        String gender = request.getParameter("gender");
        String first_name = request.getParameter("first_name");
        String sql = "select first_name,  namecount from babynames where 1=1";


        queryTopTenHelper(sql, list, yr, st, gender, first_name);

        response.getWriter().write(list.toString());
    }


    private void queryTopTenHelper(String sql, JSONArray list, String yr, String st, String gender, String
            first_name) throws SQLException {
        System.out.println("entering queryReportHelper");
        System.out.println(first_name);
        DBUtility dbutil = new DBUtility();

        if (yr != null) {
            sql += " and yr = '" + yr + "'";
        }
        if (st != null) {
            sql += " and st = '" + st + "'";
        }
        if (gender != null) {
            sql += " and gender = '" + gender + "'";
        }
        if (first_name != null) {
            sql += " and first_name = '" + first_name + "';";
        }

        sql+= " order by namecount desc limit 20";

        System.out.println("infoWindow results:" + sql);

        ResultSet res = dbutil.queryDB(sql);

        while (res.next()) {
            // add to response
            HashMap<String, String> m = new HashMap<String, String>();
            m.put("first_name", res.getString("first_name"));
            m.put("namecount", res.getString("namecount"));
            list.put(m);
        }
        System.out.println(list);
    }
    public void main() throws JSONException {
    }
}


