function queryReport(event) {
    event.preventDefault(); // stop form from submitting normally

    var a = $("#query_report_form").serializeArray();

    if (a[3].value != '') {
        a.push({name: "tab_id", value: "1"});
        a = a.filter(function (item) {
            return item.value != '';
        });
        $.ajax({
            url: 'HttpServlet',
            type: 'POST',
            data: a,
            success: function (reports) {
                mapReports(reports);
            },
            error: function (xhr, status, error) {
                alert("Status: " + status + "\nError: " + error);
            }
        });
    } else {
        a.push({name: "tab_id", value: "3"});
        a = a.filter(function (item) {
            return item.value != '';
        });
        console.log("entering queryTopTen");
        $.ajax({
            url: 'HttpServlet',
            type: 'POST',
            data: a,
            success: function (reports) {
                console.log("success in queryTopTen"+reports);
                buildTopTen(reports);
            },
            error: function (xhr, status, error) {
                alert("An AJAX error occurred: " + status + "\nError: " + error);
            }
        });
        console.log("exiting query Top Ten");
    }
}

function mapReports(reports) {

    var mapOptions = {
        center: new google.maps.LatLng(39.8097343, -98.5556199),
        zoom: 4,
        mapTypeId: google.maps.MapTypeId.TERRAIN,
        // Set the type of Map
    };

    // Render the map within the empty div
    map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);


    $.each(reports, function (i, e) {
        var long = Number(e['longitude']);
        var lat = Number(e['latitude']);
        var latlng = new google.maps.LatLng(lat, long);


        // Create the infoWindow content
        var contentStr = '<h4>Baby Names</h4><hr>';
        contentStr += '<p><b>' + 'Name' + ':</b>&nbsp' + e['first_name'] + '</p>';
        contentStr += '<p><b>' + 'Year' + ':</b>&nbsp' + e['yr'] + '</p>';
        contentStr += '<p><b>' + 'Count' + ':</b>&nbsp' + e['namecount'] +
            '</p>';
//
        var circleColor = {
            M: {
                color: '#0000ff'
            },
            F: {color: '#FF0000'}
        };
// Add a Circle overlay to the map.
        var marker = new google.maps.Circle({
            center: latlng, // Position marker to coordinates
            map: map, // assign the market to our map variable
            customInfo: contentStr,
            strokeColor: circleColor[e['gender']].color,
            strokeOpacity: 0.3,
            strokeWeight: 2,
            fillColor: circleColor[e['gender']].color,
            fillOpacity: 0.2,
            radius: Math.sqrt(e['namecount']) * 10000
        });


        var infowindow = new google.maps.InfoWindow();

        // Add a Click Listener to the marker
        marker.addListener('click', function () {
            // use 'customInfo' to customize infoWindow
            infowindow.setPosition(marker.getCenter());
            infowindow.setContent(marker['customInfo']);
            infowindow.open(map, marker); // Open InfoWindow
        });


    });

}

// function queryTopTen(reports, request) {
//     var a = $("#query_report_form").serializeArray();


function buildTopTen(reports) {
    console.log("entering buildTopTen"+reports);
    var table_head='';
    table_head += '<div class="divTableHead">Name</div>';
    table_head +=  '<div class="divTableHead">Babies Born</div>';
    var table_body = '';
    for (var i = 0; i < reports.length; i++) {
        table_body += '<div class="divTableRow">';
        table_body += '<div class="divTableCell">' + reports[i].first_name.toString() + '</div>';
        console.log(reports[i].first_name.toString());
        table_body += '<div class="divTableCell">' + reports[i].namecount.toString() + '</div>';
        console.log(reports[i].namecount.toString());
        table_body += '</div>';
    }
    $('#tableheading').html(table_head);
    $('#tablebody').html(table_body);

    console.log("exiting buildTopTen");

}

$("#query_report_form").on("submit", queryReport);


