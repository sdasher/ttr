function createReport(event) {
    event.preventDefault();
    var a = $("#queriednames_form").serializeArray();
    //indicate that "a" is a tab_1 or CREATE REPORT event
    a.push({ name: "tab_id", value: "0" });
    a.push({ name: "name", value: "Orphelia"});

    //Do Ajax POST request
    $.ajax({
        url: 'HttpServlet',
        type: 'POST',
        data: a,
        success: function (report) {
            //Pop-Up Alert Box if the Query works
            //alert("The report is successfully submitted!");

            //Reset the form
           // document.getElementById("queriednames_form").reset();
          //  $("#queriednames_form").find(".additional_msg_div").css("visibility", "hidden");

        },
        error: function (xhr, status, error) {
            alert("An AJAX error occurred: " + status + "\nError: " + error);
        }

    });
}

$("#queriednames_form").on("submit",createReport);
