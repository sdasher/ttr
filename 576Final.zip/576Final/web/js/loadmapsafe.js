var map;
var place
var autocomplete;

var infowindow = new google.maps.InfoWindow();

function initialization() {
    mapInitialization();
}

function showQueryList() {
    $.ajax({
        url: 'HttpServlet',
        type: 'POST',
        data: {"tab_id": "2"},
        success: function (reports) {

            listInitialization(reports);

        },
        error: function (xhr, status, error) {
            alert("An AJAX error occurred: " + status + "\nError: " + error);
        }
    });
}
function showAllReports() {
    $.ajax({
        url: 'HttpServlet',
        type: 'POST',
        data: {"tab_id": "1"},
        success: function (reports) {



        },
        error: function (xhr, status, error) {
            alert("An AJAX error occurred: " + status + "\nError: " + error);
        }
    });
}

function mapInitialization() {

    var mapOptions = {
        mapTypeId: google.maps.MapTypeId.TERRAIN,
        center: new google.maps.LatLng(39.8097343, -98.5556199),
        zoom: 4
    };// Set the type of Map

    // Render the map within the empty div
    var map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);

}

function mapReports(reports) {

    var mapOptions = {
        center: new google.maps.LatLng(39.8097343, -98.5556199),
        zoom:4,
        mapTypeId: google.maps.MapTypeId.TERRAIN,
        // Set the type of Map
    };

    // Render the map within the empty div
    map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);

    var bounds = new google.maps.LatLngBounds();

    $.each(reports, function (i, e) {
        var long = Number(e['longitude']);
        var lat = Number(e['latitude']);
        var latlng = new google.maps.LatLng(lat, long);
        bounds.extend(latlng);


        // Create the infoWindow content
        var contentStr = '<h4>Baby Names</h4><hr>';
        contentStr += '<p><b>' + 'Name' + ':</b>&nbsp' + e['first_name'] + '</p>';
        contentStr += '<p><b>' + 'Year' + ':</b>&nbsp' + e['yr'] + '</p>';
        contentStr += '<p><b>' + 'Count' + ':</b>&nbsp' + e['namecount'] +
            '</p>';

// Add a Circle overlay to the map.
        var marker = new google.maps.Circle({
            center: latlng, // Position marker to coordinates
            map: map, // assign the market to our map variable
            customInfo: contentStr,
            strokeColor: '#FF0000',
            strokeOpacity: 0.3,
            strokeWeight: 2,
            fillColor: '#FF0000',
            fillOpacity: 0.2,
            radius: Math.sqrt(e['namecount']) * 10000
        });

        // circle.bindTo('center', marker, 'position');
        console.log("added circle" + marker.radius);
        // Add a Click Listener to the marker
        marker.addListener('click', function () {
            console.log('clicked');
            // use 'customInfo' to customize infoWindow
            infowindow.setPosition(marker.getCenter());
            infowindow.setContent(marker['customInfo']);
            infowindow.open(map, marker); // Open InfoWindow
        });


    });

    map.fitBounds(bounds);

}

//Execute our 'initialization' function once the page has loaded.
google.maps.event.addDomListener(window, 'load', initialization);