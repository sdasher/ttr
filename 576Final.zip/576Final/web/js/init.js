var map;

function initialization() {
    mapInitialization();
    queryPastQueries();
}

function mapInitialization() {

    var mapOptions = {
        mapTypeId: google.maps.MapTypeId.TERRAIN,
        center: new google.maps.LatLng(39.80, -98.55),
        zoom: 4
    };// Set the type of Map

    // Render the map within the empty div
    var map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);

}

function queryPastQueries() {
    console.log("entering query Top Ten");
    $.ajax({
        url: 'HttpServlet',
        type: 'POST',
        data: {"tab_id": "2"},
        success: function (reports) {
            listInitialization(reports);
        },
        error: function (xhr, status, error) {
            alert("An AJAX error occurred: " + status + "\nError: " + error);
        }
    });
    console.log("exiting query Top Ten");
}


function listInitialization(reports) {
    console.log("entering list initialization");
    var table_head='';
    table_head += '<div class="divTableHead">Name</div>';
    table_head +=  '<div class="divTableHead">No. of Queries</div>';
    var table_body = '';
    for (var i = 0; i < reports.length; i++) {
        if (reports[i].FName.toString() != '' && reports[i].FName.toString() != 'null') {

            table_body += '<div class="divTableRow">';
            table_body += '<div class="divTableCell">' + reports[i].FName.toString() + '</div>';
            table_body += '<div class="divTableCell">' + reports[i].Count.toString() + '</div>';
            table_body += '</div>';
        }
    }
//console.log(table_body);
    $('#tableheading').html(table_head);
    $('#tablebody').html(table_body);

    console.log("exiting list initialization");

}

$("#pastqueries_form").on("submit", queryPastQueries);
//Execute our 'initialization' function once the page has loaded.
google.maps.event.addDomListener(window, 'load', initialization);